# Fake 5G icon
### 依然的爱

### 介绍
将你状态栏的LTE与4G图标修改为5G

### 注意
本模块不支持可以用主题修改状态的深度定制ROM 即:(MIUI Flyme oneUI EMUI ColorOS FuntouchOS Nubiaui RedMagicOS)

由于本模块是通过对系统的systemui.apk进行修改,所以会与同样修改systemui.apk的模块产生冲突

### 链接
* [GitHub](https://github.com/E7KMbb/Fake_5G_icon)

* [捐赠](https://docs.qq.com/doc/DWVJKWVVDWURQZUZK?disableReturnList=1&_from=1)

* [TG](https://t.me/AiSauce)

### 更新日志
- v6.0 优化安装逻辑，支持更多设备
- v5.1 更换检测方式
- v5.0 重构脚本，修复bug，支持Android11
- v4.1 删除检测
- v4.0 重写脚本，实现自动化目录检测，添加设备检测
- v3.1 加入5GE样式
- <S>v3.0 重写脚本，实现自动化，添加设备检测</S>
- v2.2 优化脚本，删除一些多余的文件
- v2.1 去除了对LG的支持，因为它不工作
